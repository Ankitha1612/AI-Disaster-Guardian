from typing import Dict, Any
import uuid
class SessionMemory:
    def __init__(self):
        self.store: Dict[str, Dict[str, Any]] = {}
    def create_session(self) -> str:
        sid = str(uuid.uuid4())
        self.store[sid] = {'turns': []}
        return sid
    def get(self, session_id: str) -> Dict[str, Any]:
        return self.store.get(session_id, {})
    def append_turn(self, session_id: str, user_text: str, bot_text: str):
        if session_id not in self.store:
            self.store[session_id] = {'turns': []}
        self.store[session_id]['turns'].append({'user': user_text, 'bot': bot_text})
