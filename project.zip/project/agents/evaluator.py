"""Evaluator: simple rule check."""
from typing import Dict, Any
class Evaluator:
    def __init__(self):
        self.deny_list = ['drink seawater','use gasoline','do surgery']
    def evaluate(self, worker_outputs: Dict[str, Any]) -> Dict[str, Any]:
        triggered = []
        for k,v in worker_outputs.items():
            res = v.get('result') if isinstance(v, dict) else None
            if isinstance(res, dict):
                for item in res.get('steps',[]):
                    for rule in self.deny_list:
                        if rule in item.lower():
                            triggered.append(rule)
        return {'decision': 'approve' if not triggered else 'escalate', 'triggered_rules': triggered}
