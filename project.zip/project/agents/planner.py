"""Planner agent - minimal."""
import uuid
from typing import Dict, Any
class Planner:
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
    def build_plan(self, input_text: str, session_snapshot: Dict[str, Any]) -> Dict[str, Any]:
        plan_id = str(uuid.uuid4())
        lower = (input_text or "").lower()
        tasks = []
        # always create safety and communication, verification if claim-like
        tasks.append({'worker': 'safety', 'payload': {'text': input_text}})
        if any(k in lower for k in ['shelter','closed','fake','rumor','reported']):
            tasks.insert(0, {'worker': 'verification', 'payload': {'text': input_text}})
        tasks.append({'worker': 'communication', 'payload': {'text': input_text}})
        return {'plan_id': plan_id, 'tasks': tasks, 'session_snapshot': session_snapshot}
