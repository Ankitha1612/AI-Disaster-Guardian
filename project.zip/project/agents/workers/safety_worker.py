"""Safety worker: small template responses."""
from typing import Dict, Any
class SafetyWorker:
    def __init__(self):
        pass
    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        text = (payload.get('text') or "").lower()
        if 'fire' in text or 'smoke' in text:
            steps = [
                'Leave the building immediately and use stairs, not elevators.',
                'Cover your mouth with cloth if smoke is present.',
                'Call emergency services.'
            ]
        elif 'flood' in text or 'water' in text:
            steps = [
                'Move to higher ground immediately.',
                'Avoid walking/driving through flood water.',
                'Turn off electricity if safe.'
            ]
        else:
            steps = ['Stay calm and describe your situation.']
        return {'result': {'steps': steps}, 'confidence': 0.95}
