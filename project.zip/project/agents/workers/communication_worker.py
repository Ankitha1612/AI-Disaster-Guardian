"""Communication worker: safe formatting."""
from typing import Dict, Any
class CommunicationWorker:
    def __init__(self):
        pass
    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        text = payload.get('text', '')
        message = "User input: {}\n(Instructions)".format(text)
        return {'result': {'message': message}, 'confidence': 0.9}
