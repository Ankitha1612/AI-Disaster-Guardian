"""Verification worker: very small stub."""
from typing import Dict, Any
class VerificationWorker:
    def __init__(self):
        pass
    def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        text = (payload.get('text') or "").lower()
        # trivial heuristic: if contains 'closed' -> refute, else insufficient/support
        if 'closed' in text or 'fake' in text:
            return {'result': 'refute', 'confidence': 0.8, 'provenance': []}
        return {'result': 'insufficient', 'confidence': 0.5, 'provenance': []}
