"""Worker dispatcher (minimal)."""
from project.agents.workers.communication_worker import CommunicationWorker
from project.agents.workers.verification_worker import VerificationWorker
from project.agents.workers.safety_worker import SafetyWorker

class Worker:
    def __init__(self):
        self.communication = CommunicationWorker()
        self.verification = VerificationWorker()
        self.safety = SafetyWorker()

    def run(self, worker_name: str, payload: dict):
        if worker_name == "communication":
            return self.communication.run(payload)
        if worker_name == "verification":
            return self.verification.run(payload)
        if worker_name == "safety":
            return self.safety.run(payload)
        return {"result": None, "confidence": 0.0}
