"""MainAgent: orchestrates planner, worker, evaluator and exposes run_agent()."""
from project.agents.planner import Planner
from project.agents.worker import Worker
from project.agents.evaluator import Evaluator
from project.memory.session_memory import SessionMemory
from project.core.observability import log_event

class MainAgent:
    def __init__(self):
        self.planner = Planner()
        self.worker = Worker()
        self.evaluator = Evaluator()
        self.session_store = SessionMemory()
    def handle_message(self, user_input: str) -> dict:
        session_id = self.session_store.create_session()
        log_event('incoming_message', {'session_id': session_id, 'text': user_input})
        plan = self.planner.build_plan(user_input, {})
        worker_outputs = {}
        for task in plan.get('tasks', []):
            name = task.get('worker')
            payload = task.get('payload', {})
            out = self.worker.run(name, payload)
            worker_outputs[name] = out
        eval_result = self.evaluator.evaluate(worker_outputs)
        if eval_result.get('decision') == 'approve':
            parts = []
            if 'verification' in worker_outputs:
                parts.append('Verification: {}'.format(worker_outputs['verification'].get('result')))
            if 'safety' in worker_outputs:
                steps = worker_outputs['safety']['result'].get('steps',[])
                parts.append('Safety steps:\n' + '\n'.join('- ' + s for s in steps))
            response = '\n\n'.join(parts) if parts else 'No actionable info.'
        else:
            response = 'Escalated to human review.'
        self.session_store.append_turn(session_id, user_input, response)
        log_event('outgoing_response', {'session_id': session_id, 'response': response})
        return {'response': response, 'eval': eval_result, 'workers': worker_outputs}

def run_agent(user_input: str):
    agent = MainAgent()
    result = agent.handle_message(user_input)
    return result['response']
