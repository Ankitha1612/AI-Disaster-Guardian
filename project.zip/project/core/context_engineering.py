"""Context engineering utilities and templates."""
from typing import Dict, Any

class ContextEngineering:
    @staticmethod
    def build_safety_template(disaster_type: str, language: str = 'en') -> Dict[str, Any]:
        templates = {
            'flood': [
                'If indoors: move to upper floor and stay away from electrical outlets.',
                'If outdoors: move to higher ground and avoid walking through floodwater.',
                'Do not drive through flooded roads.'
            ],
            'earthquake': [
                'Drop, Cover, and Hold on. Stay away from windows and heavy objects.',
                'If outdoors, move to an open area away from buildings.',
                'Check yourself and others for injuries.'
            ],
            'fire': [
                'Leave the building immediately and use stairs, not elevators.',
                'Cover your mouth with cloth if smoke is present.',
                'Call emergency services from a safe location.'
            ],
            'general': [
                'Stay calm and assess immediate danger.',
                'Call local emergency services if needed.',
                'Follow instructions from local authorities.'
            ]
        }
        return {'disaster_type': disaster_type, 'steps': templates.get(disaster_type, templates['general'])}
