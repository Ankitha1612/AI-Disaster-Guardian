import time, json
def log_event(event_type: str, payload: dict):
    entry = {'ts': time.time(), 'event': event_type, 'payload': payload}
    print(json.dumps(entry))
